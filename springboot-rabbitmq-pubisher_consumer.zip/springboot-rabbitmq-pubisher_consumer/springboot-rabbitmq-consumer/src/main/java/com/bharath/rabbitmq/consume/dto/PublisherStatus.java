package com.bharath.rabbitmq.consume.dto;

public enum PublisherStatus {
    PENDING,DECLINED,ACCEPTED;
}
