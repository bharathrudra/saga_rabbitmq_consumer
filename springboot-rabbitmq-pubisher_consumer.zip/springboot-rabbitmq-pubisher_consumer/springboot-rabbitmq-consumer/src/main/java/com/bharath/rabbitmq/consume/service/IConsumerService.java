package com.bharath.rabbitmq.consume.service;


import com.bharath.rabbitmq.consume.dto.Publisher;
import com.bharath.rabbitmq.consume.dto.Product;
import com.bharath.rabbitmq.consume.dto.Consumer;

public interface IConsumerService {

    void consumerMessageFromQueue(Publisher publisher);

    void purchaseOperation(Publisher publisher);

    void create(Consumer consumer);

    Consumer addMoney(Consumer consumer);

    Consumer deductMoney(Double payment, Consumer consumer);

    void createProduct(Product product);
}
