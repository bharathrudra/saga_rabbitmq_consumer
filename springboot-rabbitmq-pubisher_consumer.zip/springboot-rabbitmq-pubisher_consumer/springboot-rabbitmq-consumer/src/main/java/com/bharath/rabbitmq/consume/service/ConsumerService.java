package com.bharath.rabbitmq.consume.service;

import com.bharath.rabbitmq.consume.config.MessagingConfig;
import com.bharath.rabbitmq.consume.dto.Publisher;
import com.bharath.rabbitmq.consume.dto.PublisherStatus;
import com.bharath.rabbitmq.consume.dto.Product;
import com.bharath.rabbitmq.consume.dto.Consumer;
import com.bharath.rabbitmq.consume.repository.ProductRepository;
import com.bharath.rabbitmq.consume.repository.ConsumerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService implements IConsumerService {
    private Logger  logger = LoggerFactory.getLogger(ConsumerService.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ConsumerRepository consumerRepository;

    //@Autowired
    //private MongoTemplate mongoTemplate;

    @RabbitListener(queues = MessagingConfig.PUBLISHER_QUEUE)
    @Override
    public void consumerMessageFromQueue(Publisher publisher) {
        Publisher receivedPublisher = publisher;
        System.out.println("##### received Publisher $$$$$"+ receivedPublisher);
        logger.info("##### received Publisher $$$$$ {}", receivedPublisher);
        //if the order is placed for more then 6 qty - denied the service
        purchaseOperation(receivedPublisher);
    }

    @Override
    public void purchaseOperation(Publisher publisher) {
        try {
            Consumer dbConsumer = consumerRepository.findById(publisher.getConsumerId()).get();
            Product product = productRepository.findById(publisher.getProductId()).get();
            validateAndInitiatePayment(publisher, dbConsumer, product);
        }catch(Exception e){
            logger.error(" error occurred in purchaseOperation - full message "+e.getMessage());
            e.fillInStackTrace();
        }
        rabbitTemplate.convertAndSend(MessagingConfig.CONSUMER_QUEUE, publisher);
    }

    private void validateAndInitiatePayment(Publisher publisher, Consumer dbConsumer, Product product) {
        Boolean balFlag = (publisher.getPrice()*product.getQty()) > dbConsumer.getBalance() ? Boolean.FALSE : Boolean.TRUE;
        Boolean qtyFlag = publisher.getQty() > product.getQty() ? Boolean.FALSE : Boolean.TRUE;
        System.out.println("**** BALANCE FLAG ***"+balFlag);
        System.out.println("**** QUANTITY FLAG ***"+qtyFlag);
        if(!qtyFlag){
            System.out.println("!!!!!!!! DECLINED !!!!!!!!!!!!!!!!!"+ publisher);
            //send the message for denial of order
            publisher.setStatus(PublisherStatus.DECLINED);
            publisher.setMessage("!! INSUFFICIENT QUANTITY, REGRET FOR INCONVENIENCE !!");
        }else if (!balFlag){
            System.out.println("!!!!!!!! DECLINED !!!!!!!!!!!!!!!!!"+ publisher);
            //send the message for denial of order
            publisher.setStatus(PublisherStatus.DECLINED);
            publisher.setMessage("!! INSUFFICIENT BALANCE, PLEASE TOP-UP WALLET BEFORE PURCHASE !!");
        }else{
            System.out.println("!!!!!!!! ACCEPTED !!!!!!!!!!!!!!!!!"+ publisher);
            deductMoney(publisher.getPrice(), dbConsumer);
            deductQuantity(publisher.getQty(), product);
            //send the message - order accepted
            publisher.setStatus(PublisherStatus.ACCEPTED);
            publisher.setMessage("!! ORDER ACCEPTED !!");
        }
    }

    private void deductQuantity(int qty, Product product) {
        int quantity = product.getQty() - qty;
        product.setQty(quantity);
        productRepository.save(product);
    }

    @Override
    public void create(Consumer consumer) {
        consumerRepository.save(consumer);
    }

    public Consumer addMoney(Consumer consumer) {
        Consumer dbConsumer = consumerRepository.findById(consumer.getConsumerId()).get();
        Double amtToBeAdded = dbConsumer.getBalance()+ consumer.getBalance();
        dbConsumer.setBalance(amtToBeAdded);
        consumerRepository.save(dbConsumer);
        return dbConsumer;
    }

    public Consumer deductMoney(Double payment, Consumer consumer) {
        Double amtAfterPurchase = consumer.getBalance()-payment;
        consumer.setBalance(amtAfterPurchase);
        consumerRepository.save(consumer);
        return consumer;
    }

    @Override
    public void createProduct(Product product) {
        productRepository.save(product);
    }
}
