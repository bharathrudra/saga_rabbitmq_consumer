package com.bharath.rabbitmq.consume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRabbitmqConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRabbitmqConsumerApplication.class, args);
	}

}
