package com.bharath.rabbitmq.consume.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Publisher {
    private int publisherId;
    private int productId;
    private int qty;
    private double price;
    private int consumerId;
    private PublisherStatus status;
    private String message;
}
