package com.bharath.rabbitmq.consume.controller;

import com.bharath.rabbitmq.consume.dto.Product;
import com.bharath.rabbitmq.consume.dto.Consumer;
import com.bharath.rabbitmq.consume.service.IConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
public class ConsumerController {

    @Autowired
    private IConsumerService consumerService;

    @PostMapping("/consumer/create")
    public Consumer createConsumer(@RequestBody Consumer consumer){
        consumerService.create(consumer);
        return consumer;
    }

    @PostMapping("/product/create")
    public Product createProduct(@RequestBody Product product){
        consumerService.createProduct(product);
        return product;
    }

    @PutMapping("/consumer/addMoney")
    public Consumer addMoney(@RequestBody Consumer consumer){
        return consumerService.addMoney(consumer);
    }

    //test method for now
    @GetMapping("/get")
    public String getOrder() {
//        order.setOrderId(UUID.randomUUID().toString());
//        //restaurant service
//        //payment service
//        OrderStatus orderStatus = new OrderStatus(order, "PROCESS", "order placed succesfully in " + restaurantName);
//        template.convertAndSend(MessagingConfig.EXCHANGE, MessagingConfig.ROUTING_KEY, orderStatus);
        return "get Success !!";
    }
}
