package com.bharath.rabbitmq.consume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
