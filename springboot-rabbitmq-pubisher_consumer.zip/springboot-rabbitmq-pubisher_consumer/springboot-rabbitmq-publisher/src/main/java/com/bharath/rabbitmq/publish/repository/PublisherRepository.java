package com.bharath.rabbitmq.publish.repository;

import com.bharath.rabbitmq.publish.dto.Publisher;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
@EnableJpaRepositories
public interface PublisherRepository extends CrudRepository<Publisher,Integer> {
}
