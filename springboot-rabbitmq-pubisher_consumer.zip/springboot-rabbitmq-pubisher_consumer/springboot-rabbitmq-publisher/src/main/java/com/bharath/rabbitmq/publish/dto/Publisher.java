package com.bharath.rabbitmq.publish.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "publish_table")
public class Publisher {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int publisherId;
    @Column(name = "product_id")
    private int productId;
    @Column
    private int qty;
    @Column
    private double price;
    @Column(name = "consumer_id")
    private int consumerId;
    @Column
    @Enumerated(EnumType.ORDINAL)
    private PublisherStatus status;
    @Column
    private String message;
}
