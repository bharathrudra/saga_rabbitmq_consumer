package com.bharath.rabbitmq.publish.service;

import com.bharath.rabbitmq.publish.config.MessagingConfig;
import com.bharath.rabbitmq.publish.dto.Publisher;
import com.bharath.rabbitmq.publish.dto.PublisherStatus;
import com.bharath.rabbitmq.publish.repository.PublisherRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PublisherServiceImpl implements IPublisherService {

    Logger logger = LoggerFactory.getLogger(PublisherServiceImpl.class);
    public static final String PUBLISH_VERIFICATION_IN_PROGRESS = "Publish Verification IN PROGRESS";
    @Autowired
    private PublisherRepository publisherRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private Publisher receivedPublisherFromQueue;

    @RabbitListener(queues = MessagingConfig.CONSUMER_QUEUE)
    @Override
    public void publishUpdateMessageFromQueue(Publisher publisher) {
        receivedPublisherFromQueue = publisher;
        logger.info(" #### received published Order FromQueue $$$$$ {}", receivedPublisherFromQueue);
        updatePublishOrder(publisher);
    }

    @Override
    public String createPublishOrder(Publisher publisher)  {
        try {
            publisher.setStatus(PublisherStatus.PENDING);
            publisher.setMessage(PUBLISH_VERIFICATION_IN_PROGRESS);
            publisherRepository.save(publisher);
            logger.info(" ############# Message Published Order &&&&&&&&&&& {}", publisher);
            rabbitTemplate.convertAndSend(MessagingConfig.PUBLISHER_QUEUE, publisher);
            //kafkaTemplate.send(MessagingConfig.ORDER_TOPIC,order);

        }catch(Exception e){
            logger.error("exception raised - full message here "+e.getMessage());
        }
        return publisher.getMessage();
    }

    @Override
    public void updatePublishOrder(Publisher publisher) {
        publisherRepository.save(publisher);
    }

    @Override
    public String getPublishStatusFromQueue() {

        return receivedPublisherFromQueue.getStatus()
                +"!! Message !!"+ receivedPublisherFromQueue.getMessage();
    }
}
