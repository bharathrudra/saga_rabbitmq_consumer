package com.bharath.rabbitmq.publish.controller;

import com.bharath.rabbitmq.publish.dto.Publisher;
import com.bharath.rabbitmq.publish.service.IPublisherService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/publisher")
public class PublisherController {

    @Autowired
    private RabbitTemplate template;

    @Autowired
    private IPublisherService iPublisherService;

    @PostMapping("/doPublish")
    public String doPublish(@RequestBody Publisher publisher) {
        return iPublisherService.createPublishOrder(publisher);
    }


    @GetMapping("/publishStatus")
    public String checkStatus(){
        return iPublisherService.getPublishStatusFromQueue();
    }


    //test method for now
    @PostMapping("/get")
    public String getPublishOrder() {
        return "get Success !!";
    }
}
