package com.bharath.rabbitmq.publish.dto;

public enum PublisherStatus {
    PENDING,DECLINED,ACCEPTED;
}
