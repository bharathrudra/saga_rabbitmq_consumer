package com.bharath.rabbitmq.publish.service;

import com.bharath.rabbitmq.publish.dto.Publisher;

public interface IPublisherService {

    void publishUpdateMessageFromQueue(Publisher publisher);

    String createPublishOrder(Publisher publisher) ;

    void updatePublishOrder(Publisher publisher);

    String getPublishStatusFromQueue();
}
