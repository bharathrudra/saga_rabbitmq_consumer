package com.bharath.rabbitmq.publish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqPublisherApplicationTests {

	@Test
	void contextLoads() {
	}

}
